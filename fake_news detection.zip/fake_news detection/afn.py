import streamlit as st
from pypmml import Model  # type: ignore

# Load the PMML model once
model = Model.load(r"Z:\Fake_news_detection\Truth Seeker Dataset\python.xml")

st.title("📰 Fake News Detection App")

# Input fields
information = st.text_area("📝 Enter the news information:")
country = st.selectbox(
    "🌍 Select Country:",
    ["Brazil", "Canada", "China", "Germany", "India", "Mexico", "Russia", "USA"]
)
forwarded_count = st.number_input("🔁 Forwarded Count:", min_value=0, value=3000)
likes = st.number_input("👍 Likes:", min_value=0, value=10000)
total_followers = st.number_input("👥 Total Followers:", min_value=0, value=200000)
post_followers = st.number_input("👥 Post Followers:", min_value=0, value=100000)

# Predict button
if st.button("🔎 Predict"):
    input_data = {
        'Country': country,
        'Forwarded_Count': forwarded_count,
        'Likes': likes,
        'Total_Followers': total_followers,
        'Post_Followers': post_followers
    }

    # Show input
    st.subheader("🛠️ Input Passed to Model:")
    st.json(input_data)

    # Predict
    result = model.predict(input_data)

    # Show raw output
    st.subheader("🧾 Full Raw Model Output:")
    st.json(dict(result))

    # Final prediction
    st.subheader("🧠 Prediction Result:")
    if result['True_or_False'] == 1:
        st.error("⚠️ This news is predicted as **FAKE** 🟥")
    else:
        st.success("✅ This news is predicted as **REAL**")
